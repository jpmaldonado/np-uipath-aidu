from aiflib.model import Model
import json

class Main(object):
    def __init__(self):
        self.model = Model()

    def predict(self, payload):
        return json.dumps(self.model.predict(payload))
