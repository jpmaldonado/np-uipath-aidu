import hashlib
import random
import os
import json
from aiflib.utils import RunConfig, Logger, write_file
from aiflib.data_loader import DataLoader
from functools import partial

# Constants
_BASE_MODEL_DIR = 'base'
_FINETUNED_DIR = 'finetuned'
_SERIALIZED_MODEL_NAME = 'metadata.json'

# Utility functions.
join_path = partial(os.path.join, os.path.dirname(__file__))

class Model(object):

    def __init__(self):
        self._run_config = RunConfig()
        self.logger = Logger(__name__)
        if self._run_config.from_base or self.load_finetuned_if_exists() is None:
            self.model = self.load_base_model()
        else:
            self.model = self.load_finetuned_if_exists()

    def _load_model(self, path):
        with open(path, 'r') as infile:
            metadata = json.load(infile)
        return metadata


    def load_base_model(self):
        metadata_file = join_path(_BASE_MODEL_DIR, _SERIALIZED_MODEL_NAME)
        return self._load_model(metadata_file)

    def checkpoint_model(self, path, model):
        with open(path, 'w') as outfile:
            json.dump(model, outfile)

    def load_finetuned_if_exists(self):
        metadata_file = join_path(_FINETUNED_DIR,_SERIALIZED_MODEL_NAME)
        if not os.path.exists(metadata_file): return self.load_base_model()
        return self._load_model(metadata_file)


    def evaluate(self, directory):
        self.model = self.load_finetuned_if_exists()

        self.logger.info(
        """\n\n\n---------------Starting evaluate()---------------
           This function can be used in many ways. Maybe you as model uploader
           expect 'directory' to have a file called test.csv. Maybe there is a
           top level schema.json file that designates images as test set,
           maybe you will merge all subdirectories inside
           'directory' and use your own configuration, these are just a few
           examples of what can be done here.
            """)
        loader = DataLoader(directory)
        contents = loader.get_path_contents()
        self.logger.info(f'The contents of the directory are {contents}')

        artifacts_dir = partial(os.path.join, self._run_config.artifacts_directory)
        write_file(artifacts_dir('my-evaluate-artifact.txt'),
                   ['User can write arbitrary data like histograms, tensorboard'
                    'logs, confustion matrices, etc.'])

        score = random.choice([_/100.0 for _ in range(60, 95)])
        self.logger.info(f'Evaluation on {self.model} -> Score {score}')

        self.logger.info('---------------Evaluation done.---------------\n\n\n')

        # Sample random score to showcase comparison from UI.
        return score

    def predict(self, payload):
        choice = random.choice(self.model['output classes'])
        return {
            'prediction': choice,
            'confidence': random.random()
        }

    def process_data(self, directory):
        self.logger.info(
            """\n\n\n---------------Starting process_data()---------------
            This can be used for any preprocessing of data in raw
            format to data that is expected by the train function.

            It can also be used to split data. For example, writting
            80% of the data points in train.csv and 20% of the data
            points in test.csv""")

        loader = DataLoader(directory)
        contents = loader.get_path_contents()
        self.logger.info(f'The contents of the directory are {contents}')

        artifacts_dir = partial(os.path.join, self._run_config.artifacts_directory)
        test_dir = partial(os.path.join,
                           self._run_config.process_data_test_directory)
        train_dir = partial(os.path.join,
                            self._run_config.process_data_train_directory)

        write_file(artifacts_dir('my-process-data-artifact'),
                   ['An artifact from process_data, for example some'
                    'distribution graph of raw data'])

        write_file(test_dir('test.csv'), ['From process_data some split of data from:'] + contents)
        write_file(train_dir('train.csv'), ['From process_data some split of data from:'] + contents)

        self.logger.info('---------------Done process_data---------------\n\n\n')

    def train(self, directory):
        self.logger.info(
        """\n\n\n---------------Starting train()---------------
           This function can be used in many ways. Maybe you as model uploader
           expect 'directory' to have a file called train.csv. Maybe there is a
           top level schema.json file that designates images as trainingset or
           validation set, maybe you will merge all subdirectories inside
           'directory' and use your own configuration, these are just a few
           examples of what can be done here""")

        loader = DataLoader(directory)
        contents = loader.get_path_contents()
        self.logger.info(f'The contents of the directory are {contents}')

        # Simulate that the hash of a model will depend on the data it was
        # trained on (directory contents) and the model weights (it could have
        # been transfer learning from a base model or a finetune model depending
        # on parameters).
        contents_hash = hashlib.sha256(
            ''.join(contents + [self.model['serialized model']]).encode('utf-8')).hexdigest()

        artifacts_dir = partial(os.path.join, self._run_config.artifacts_directory)
        write_file(artifacts_dir('my-train-artifact.txt'),
                   ['User can write arbitrary data like histograms, tensorboard'
                    'logs, confustion matrices, etc.'])

        new_model = {
            'serialized model': contents_hash,
            'trained from': self.model['serialized model'],
            'output classes': self.model['output classes']
        }
        metadata_file = join_path(_FINETUNED_DIR,_SERIALIZED_MODEL_NAME)
        self.checkpoint_model(metadata_file, new_model)

        self.logger.info('---------------Done train---------------\n\n\n')

    def save(self):
        pass

