import logging
import os
from functools import partial

# Utility functions.
join_path = partial(os.path.join, os.path.dirname(__file__))

# OS environment variables.
def os_flag(name, default='false'): return str(os.environ.get(name, default)).lower() == 'true'
def os_num(name, default=-1): return float(os.environ.get(name, default))
def os_int(name, default=-1): return int(os.environ.get(name, default))
def os_param(name, default): return os.environ.get(name, default)

class RunConfig(object):
    class __SingletonRunConfig(object):
        """
        Configuration driven by env variables.
        """
        def __init__(self):
            # Force transfer learning on base model.
            self.from_base = os_flag('from_base')

            # Data parameters.
            self.process_data_train_directory = os_param('training_data_directory',
                                                join_path('..', './dataset/training'))
            self.process_data_test_directory = os_param('training_data_directory',
                                                join_path('..', './dataset/test'))

            # Set up artifacts.
            self.artifacts_directory = os_param('artifacts', join_path('..', 'artifacts'))

    instance = None
    def __init__(self):
        if not RunConfig.instance:
            RunConfig.instance = RunConfig.__SingletonRunConfig()
    def __getattr__(self, name):
        return getattr(self.instance, name)

class Logger(object):
    def __init__(self, name):
        self.runconfig = RunConfig()
        self.logger_name = name
        logging.basicConfig(format='[%(asctime)s] [%(name)s] %(message)s', level = logging.DEBUG)
        self.logger = logging.getLogger(self.logger_name)

    def info(self, msg):
        # Note using logging polutes stdout with wrapper, using print instead.
        self.logger.info('\n{}\n'.format(msg))


def write_file(path, lines):
    with open(path, 'w') as out_file:
        out_file.writelines(lines)
