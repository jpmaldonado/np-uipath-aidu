from aiflib.utils import Logger, RunConfig
import os

class DataLoader(object):
    def __init__(self, path):
        config = RunConfig()

        self.logger = Logger(__name__)
        self.logger.info('Loading data from {}...'.format(path))
        self.path = path

    def get_path_contents(self):
        return [l for l in os.listdir(self.path)]



