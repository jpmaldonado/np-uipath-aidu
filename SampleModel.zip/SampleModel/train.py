from aiflib.model import Model

class Main(object):
    def __init__(self):
        self.model = Model()

    def train(self, directory):
        self.model.train(directory)

    def evaluate(self, directory):
        return self.model.evaluate(directory)

    def process_data(self, directory):
        self.model.process_data(directory)

    def save(self):
        self.model.save()

